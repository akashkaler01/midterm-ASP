﻿namespace _200571587.Data
{
    using _200571587.Models.YourProjectNamespace.Models;
    using Microsoft.EntityFrameworkCore;

    namespace YourProjectNamespace.Data
    {
        public class ApplicationDbContext : DbContext
        {
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
            {
            }

            public DbSet<Student> Students { get; set; }
        }
    }

}
